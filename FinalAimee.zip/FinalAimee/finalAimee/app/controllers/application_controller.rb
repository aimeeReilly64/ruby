class ApplicationController < ActionController::Base
    def page1
    end
end
