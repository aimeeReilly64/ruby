class Instructor < ApplicationRecord
end
