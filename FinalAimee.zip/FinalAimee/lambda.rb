system("cls")
#main program
subroutine = -> fib(n) do
    n = 0; i = 10
    While i <= n
    if n = 0 or n = 1 then return n
    else return fib(n-1) + fib(n-1)
    End
    Return fib(n)
    End
    Puts subroutine.call(10)   